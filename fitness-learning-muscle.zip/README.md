# fitness-learning-muscle

Project generated from PDF. Replace firebase config in src/firebase.js and run `npm install` then `npm run dev`.

Survey data stored under `users/{uid}/surveys` and quiz results under `users/{uid}/quiz_results`.

Deploy firestore rules with:
```
firebase deploy --only firestore:rules
```
